# Technical notes

## ResMed input

The parser works from standard EDF/EDF+ structures and does not call OSCAR. ResMed AirSense 10 detailed data commonly includes BRP, PLD, EVE/CSL and optional oximetry EDF files. Signal labels are interpreted dynamically rather than assuming every file contains the same channel set.

## High-resolution merge

When a Flow channel is present, its timestamp cadence is used as the master merge clock. A 25 Hz signal yields one sample every 40 ms. Slower channels are aligned by timestamp and carried forward only while their source recording is active. Separate sessions are kept separate rather than filling long gaps with artificial rows.

## EDF+ annotations

Annotation channels are decoded from TAL text. The parser accepts annotation-only files with zero-second record duration, which can appear in ResMed event files.

## Current phone workflow

Some Android USB/SD readers do not recognize older 2 GB standard-SD cards. Version 0.2 therefore uses a copied-data workflow:

1. Read the ResMed SD card on Windows.
2. Copy `DATALOG` to the phone.
3. The app creates or reuses `ResMed Data` under a parent folder selected through Android's Storage Access Framework.
4. The app creates `CSV Exports` inside `ResMed Data`.
5. The app retains the original granted tree URI and stores document IDs for the source and output subfolders. This avoids relying on a separately constructed child-tree permission.

The EDF parser and CSV exporter are independent of the physical storage source, so direct SD-card support can be added later without redesigning the parsing layer.

## Build versions

- AGP 9.4.0
- Gradle 9.6.0
- compileSdk 37
- targetSdk 36
- minSdk 26
- Java 17
- AGP built-in Kotlin support

## Validation status

Application Kotlin sources compile against local Android API stubs. This checks Kotlin syntax and types in the current source but is not a substitute for a full Android Gradle build or device test.
