# CPAP CSV Exporter for Android

A small Android app that reads copied ResMed EDF/EDF+ files and exports CSV files without requiring OSCAR or Python on the phone.

## Version 0.2 workflow

This version is designed for a phone/card-reader combination that cannot read the older 2 GB ResMed SD card directly.

1. Read the ResMed SD card on Windows.
2. Copy the whole `DATALOG` folder, or the EDF files and dated folders inside it, onto the phone.
3. In the app, tap **Create or choose ResMed Data folder**. Choose a parent location such as **Documents**.
4. The app creates or reuses `ResMed Data` and creates `ResMed Data/CSV Exports`.
5. Put the copied ResMed data inside `ResMed Data`.
6. Tap **Scan available nights**.
7. Choose the sleep date.
8. Export one merged CSV or separate CSV files.

The app keeps Android's original persisted folder permission and addresses the two subfolders through that permission, so access can survive closing and reopening the app.

## What it does

- Uses Android's system folder picker; no broad storage permission and no Internet permission.
- Scans copied ResMed `DATALOG` data for dated folders and EDF files.
- Lets the user choose a sleep date.
- Parses standard 16-bit EDF signals and EDF+ annotations.
- Converts EDF digital samples to physical values using each signal's calibration fields.
- Reads high-resolution BRP waveforms such as `Flow.40ms` and `Press.40ms`.
- Reads PLD channels such as pressure, leak, respiratory rate, tidal volume, minute ventilation, snore, and flow limitation when present.
- Reads SA2/SAD pulse and SpO2 channels when present.
- Reads EVE/CSL EDF+ annotations and places them on a common timeline.
- Exports either one merged CSV for the selected sleep date or one CSV for every EDF file.

The merged CSV uses Flow as its master clock when Flow is available. On a typical 25 Hz ResMed BRP file this produces one row every 40 ms. Slower signals are held at their most recent sample while their EDF series is active. Gaps between separate CPAP sessions are not expanded into blank high-frequency rows.

## Output

The merged file begins with columns similar to:

```text
timestamp_local,epoch_ms,flow_rate,mask_pressure_wave,...,event,event_duration_seconds
```

Additional columns appear only when the corresponding signals are present. Unknown EDF labels are preserved as sanitized source-prefixed columns instead of being discarded.

CSV files are written to:

```text
ResMed Data/CSV Exports
```

Re-exporting the same generated filename replaces the prior CSV when the Android storage provider permits deletion.

## Build

The project targets:

- compile SDK API 37
- target SDK API 36
- minimum Android API 26
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- Java 17

The project contains `.github/workflows/build-apk.yml`. When placed in a GitHub repository, that workflow builds an installable debug APK and publishes it as an Actions artifact named **CPAP-CSV-Exporter-APK**. See `BUILD_APK.md`.

It can also be opened and built in a current Android Studio installation.

## Validation performed in this workspace

- The Kotlin sources were compiled against local Android API stubs to catch Kotlin syntax/type errors in the application code.
- The EDF parser and CSV logic were previously smoke-tested with generated EDF data containing 25 Hz flow/pressure channels, physical/digital scaling, an EDF+ annotation-only event file, a fractional-second hypopnea, and an annotation file with zero-second record duration.

The app still needs testing on a physical Android phone with actual raw AirSense 10 EDF files before its exports should be treated as fully validated.

## Known limitations

- It has not yet been installed and tested on the user's Motorola phone.
- It assumes sampled ResMed BRP/PLD/SA2/SAD files are contiguous EDF recordings. Annotation-only EDF+D files are supported, but discontinuous sampled EDF+D waveform reconstruction is not yet implemented.
- EDF timestamps do not carry a timezone. The app interprets them using the Android phone's current timezone. Keep the phone and CPAP clocks aligned when correlating a seizure video with CSV data.
- It does not diagnose seizures or calculate medical conclusions. It exports recorded CPAP signals and annotations for later analysis.
- A full 25 Hz Flow export is large: roughly 90,000 rows per hour of therapy.

## Project structure

- `edf/EdfParser.kt` — EDF/EDF+ reader and calibration
- `export/CsvExporter.kt` — signal naming, synchronization, and CSV streaming
- `storage/StorageTree.kt` — Android Storage Access Framework access
- `storage/NightScanner.kt` — ResMed date/night discovery
- `MainActivity.kt` — simple accessible Android UI
- `.github/workflows/build-apk.yml` — cloud APK build workflow

## Privacy and scope

This is an independent personal-data export utility. It is not affiliated with, endorsed by, or a replacement for ResMed, OSCAR, or a medical professional.
