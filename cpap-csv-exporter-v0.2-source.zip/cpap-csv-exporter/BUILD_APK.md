# Build the installable APK

The project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.
It builds an installable Android debug APK automatically.

## Easiest build route

1. Put this project in a GitHub repository.
2. Open the repository's **Actions** tab.
3. Choose **Build installable APK**.
4. Choose **Run workflow**.
5. When the build finishes, download the artifact named **CPAP-CSV-Exporter-APK**.
6. Inside that artifact is `app-debug.apk`. Copy/open that APK on the Android phone to install it.

Android may ask for permission to install an app from the browser or file manager used to open the APK. That is an Android security setting for apps installed outside Google Play.

## What the first-run app does

Tap **Create or choose ResMed Data folder**. Choose a parent location such as **Documents**. The app creates:

- `ResMed Data`
- `ResMed Data/CSV Exports`

Copy the ResMed `DATALOG` folder (or the EDF files and dated folders inside it) from Windows into `ResMed Data`.
Then use **Scan available nights** and export the chosen night.
