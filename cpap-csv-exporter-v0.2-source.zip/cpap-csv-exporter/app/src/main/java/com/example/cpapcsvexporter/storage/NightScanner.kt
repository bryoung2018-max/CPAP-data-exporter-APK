package com.example.cpapcsvexporter.storage

import com.example.cpapcsvexporter.edf.EdfParser
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class NightScanner(
    private val tree: StorageTree,
    private val zoneId: ZoneId = ZoneId.systemDefault()
) {
    data class Night(
        val date: LocalDate,
        val nodes: List<StorageTree.Node>,
        val description: String
    )

    private val folderDate = Regex("^\\d{8}$")
    private val folderFormatter = DateTimeFormatter.ofPattern("yyyyMMdd")

    fun scan(): List<Night> {
        val root = tree.root
        val direct = tree.listChildren(root)
        val dateFolders = direct.filter { it.isDirectory && folderDate.matches(it.name) }

        if (dateFolders.isNotEmpty()) {
            return dateFolders.mapNotNull { folder ->
                val date = runCatching { LocalDate.parse(folder.name, folderFormatter) }.getOrNull()
                    ?: return@mapNotNull null
                val files = collectEdfFiles(folder, maxDepth = 2)
                if (files.isEmpty()) null
                else Night(date, files, "${folder.name}: ${files.size} EDF files")
            }.sortedByDescending { it.date }
        }

        // Fallback for copied/flattened DATALOG folders: group EDF files by a noon sleep-day boundary.
        val allFiles = collectEdfFiles(root, maxDepth = 3)
        val parser = EdfParser(zoneId)
        val grouped = linkedMapOf<LocalDate, MutableList<StorageTree.Node>>()
        for (node in allFiles) {
            val start = runCatching {
                tree.openInput(node).use { parser.parse(node.name, it).header.startDateTime }
            }.getOrNull() ?: continue
            val sleepDate = if (start.hour < 12) start.toLocalDate().minusDays(1) else start.toLocalDate()
            grouped.getOrPut(sleepDate) { mutableListOf() }.add(node)
        }
        return grouped.map { (date, nodes) -> Night(date, nodes, "${nodes.size} EDF files") }
            .sortedByDescending { it.date }
    }

    private fun collectEdfFiles(start: StorageTree.Node, maxDepth: Int): List<StorageTree.Node> {
        val result = mutableListOf<StorageTree.Node>()
        fun walk(node: StorageTree.Node, depth: Int) {
            if (depth > maxDepth) return
            for (child in tree.listChildren(node)) {
                if (child.isDirectory) {
                    walk(child, depth + 1)
                } else if (child.name.endsWith(".edf", ignoreCase = true)) {
                    result += child
                }
            }
        }
        walk(start, 0)
        return result.sortedBy { it.name }
    }
}
