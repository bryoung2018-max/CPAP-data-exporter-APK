package com.example.cpapcsvexporter.edf

import java.io.EOFException
import java.io.InputStream
import java.nio.charset.Charset
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import kotlin.math.max

class EdfParser(
    private val zoneId: ZoneId = ZoneId.systemDefault()
) {
    fun parse(sourceName: String, input: InputStream): ParsedEdfFile {
        val first256 = input.readExactly(256)
        var offset = 0
        fun field(length: Int): String {
            val value = first256.copyOfRange(offset, offset + length).toAscii().trim()
            offset += length
            return value
        }

        val version = field(8)
        field(80) // patient identification: deliberately not retained
        val recordingId = field(80)
        val startDate = field(8)
        val startTime = field(8)
        val headerBytes = field(8).toIntOrNull()
            ?: throw IllegalArgumentException("Invalid EDF header length in $sourceName")
        val reserved = field(44)
        val numberOfRecords = field(8).toLongOrNull()
            ?: throw IllegalArgumentException("Invalid EDF data-record count in $sourceName")
        val recordDuration = field(8).toDoubleOrNull()
            ?: throw IllegalArgumentException("Invalid EDF record duration in $sourceName")
        val signalCount = field(4).toIntOrNull()
            ?: throw IllegalArgumentException("Invalid EDF signal count in $sourceName")

        require(signalCount > 0) { "EDF file contains no signals: $sourceName" }

        val remainingHeaderBytes = headerBytes - 256
        require(remainingHeaderBytes >= signalCount * 256) {
            "EDF header is too short for $signalCount signals: $sourceName"
        }
        val signalHeaderBytes = input.readExactly(remainingHeaderBytes)
        var p = 0

        fun strings(width: Int): List<String> {
            val result = ArrayList<String>(signalCount)
            repeat(signalCount) {
                result += signalHeaderBytes.copyOfRange(p, p + width).toAscii().trim()
                p += width
            }
            return result
        }

        val labels = strings(16)
        strings(80) // transducer
        val units = strings(8)
        val physicalMinimums = strings(8).map { it.toDoubleOrNull() ?: 0.0 }
        val physicalMaximums = strings(8).map { it.toDoubleOrNull() ?: 0.0 }
        val digitalMinimums = strings(8).map { it.toIntOrNull() ?: -32768 }
        val digitalMaximums = strings(8).map { it.toIntOrNull() ?: 32767 }
        strings(80) // prefilter
        val samplesPerRecord = strings(8).map {
            it.toIntOrNull() ?: throw IllegalArgumentException("Invalid EDF sample count in $sourceName")
        }
        strings(32) // reserved per signal

        val signalHeaders = labels.indices.map { i ->
            EdfSignalHeader(
                label = labels[i],
                physicalDimension = units[i],
                physicalMinimum = physicalMinimums[i],
                physicalMaximum = physicalMaximums[i],
                digitalMinimum = digitalMinimums[i],
                digitalMaximum = digitalMaximums[i],
                samplesPerRecord = samplesPerRecord[i]
            )
        }

        val hasNumericSignals = signalHeaders.any { !it.isAnnotation }
        if (hasNumericSignals) {
            require(recordDuration > 0.0) { "EDF record duration must be positive for sampled signals: $sourceName" }
        }

        val localStart = parseDateTime(startDate, startTime)
        val startEpochMillis = localStart.atZone(zoneId).toInstant().toEpochMilli()
        val sourceType = detectSourceType(sourceName)
        val builders = signalHeaders.map { header ->
            if (header.isAnnotation) null else DoubleArrayBuilder(max(1024, header.samplesPerRecord * 60))
        }
        val events = mutableListOf<EdfEvent>()

        var recordIndex = 0L
        while (numberOfRecords < 0 || recordIndex < numberOfRecords) {
            var gotAnySignal = false
            var completeRecord = true

            for (signalIndex in signalHeaders.indices) {
                val sh = signalHeaders[signalIndex]
                val byteCount = sh.samplesPerRecord * 2
                val bytes = if (!gotAnySignal) {
                    input.readExactlyOrNull(byteCount)
                } else {
                    try {
                        input.readExactly(byteCount)
                    } catch (_: EOFException) {
                        null
                    }
                }

                if (bytes == null) {
                    completeRecord = false
                    break
                }
                gotAnySignal = true

                if (sh.isAnnotation) {
                    parseAnnotationBytes(
                        bytes = bytes,
                        fileStartEpochMillis = startEpochMillis,
                        sourceName = sourceName,
                        destination = events
                    )
                } else {
                    val builder = builders[signalIndex]!!
                    var b = 0
                    while (b + 1 < bytes.size) {
                        val lo = bytes[b].toInt() and 0xff
                        val hi = bytes[b + 1].toInt()
                        val digital = (hi shl 8) or lo
                        builder.add(toPhysical(digital.toShort().toInt(), sh))
                        b += 2
                    }
                }
            }

            if (!completeRecord || !gotAnySignal) break
            recordIndex++
        }

        val series = signalHeaders.indices.mapNotNull { i ->
            val sh = signalHeaders[i]
            val builder = builders[i] ?: return@mapNotNull null
            if (sh.samplesPerRecord <= 0) return@mapNotNull null
            EdfSignalSeries(
                label = sh.label,
                unit = sh.physicalDimension,
                sourceType = sourceType,
                sourceName = sourceName,
                startEpochMillis = startEpochMillis,
                sampleIntervalMillis = (recordDuration * 1000.0) / sh.samplesPerRecord,
                values = builder.toArray()
            )
        }

        return ParsedEdfFile(
            sourceName = sourceName,
            sourceType = sourceType,
            header = EdfHeader(
                version = version,
                recordingId = recordingId,
                startDateTime = localStart,
                headerBytes = headerBytes,
                reserved = reserved,
                numberOfDataRecords = numberOfRecords,
                recordDurationSeconds = recordDuration,
                signals = signalHeaders
            ),
            signals = series,
            events = events.distinctBy { Triple(it.onsetEpochMillis, it.text, it.durationSeconds) }
                .sortedBy { it.onsetEpochMillis }
        )
    }

    private fun parseDateTime(dateText: String, timeText: String): LocalDateTime {
        val d = dateText.split('.')
        val t = timeText.split('.')
        require(d.size == 3 && t.size == 3) { "Unsupported EDF date/time: $dateText $timeText" }
        val day = d[0].toInt()
        val month = d[1].toInt()
        val yy = d[2].toInt()
        val year = if (yy >= 85) 1900 + yy else 2000 + yy
        return LocalDateTime.of(
            LocalDate.of(year, month, day),
            LocalTime.of(t[0].toInt(), t[1].toInt(), t[2].toInt())
        )
    }

    private fun toPhysical(digital: Int, h: EdfSignalHeader): Double {
        val digitalSpan = h.digitalMaximum - h.digitalMinimum
        if (digitalSpan == 0) return digital.toDouble()
        val physicalSpan = h.physicalMaximum - h.physicalMinimum
        return h.physicalMinimum +
            (digital - h.digitalMinimum).toDouble() * physicalSpan / digitalSpan.toDouble()
    }

    private fun parseAnnotationBytes(
        bytes: ByteArray,
        fileStartEpochMillis: Long,
        sourceName: String,
        destination: MutableList<EdfEvent>
    ) {
        // EDF+ annotations are byte-oriented even though their channel occupies 2-byte sample slots.
        val text = bytes.toString(Charsets.UTF_8)
        val talBlocks = text.split('\u0000')
        for (block in talBlocks) {
            if (block.isBlank()) continue
            val annotationSeparator = block.indexOf('\u0014')
            if (annotationSeparator < 0) continue

            val timing = block.substring(0, annotationSeparator)
            val durationSeparator = timing.indexOf('\u0015')
            val onsetText = if (durationSeparator >= 0) timing.substring(0, durationSeparator) else timing
            val durationText = if (durationSeparator >= 0) timing.substring(durationSeparator + 1) else ""
            val onsetSeconds = onsetText.trim().toDoubleOrNull() ?: continue
            val durationSeconds = durationText.trim().toDoubleOrNull()

            val annotations = block.substring(annotationSeparator + 1)
                .split('\u0014')
                .map { it.trim() }
                .filter { it.isNotEmpty() }

            for (annotation in annotations) {
                destination += EdfEvent(
                    onsetEpochMillis = fileStartEpochMillis + (onsetSeconds * 1000.0).toLong(),
                    durationSeconds = durationSeconds,
                    text = annotation,
                    sourceName = sourceName
                )
            }
        }
    }

    private fun detectSourceType(name: String): String {
        val upper = name.uppercase()
        return when {
            "_BRP" in upper || upper.startsWith("BRP") -> "BRP"
            "_PLD" in upper || upper.startsWith("PLD") -> "PLD"
            "_SA2" in upper || upper.startsWith("SA2") -> "SA2"
            "_SAD" in upper || upper.startsWith("SAD") -> "SAD"
            "_EVE" in upper || upper.startsWith("EVE") -> "EVE"
            "_CSL" in upper || upper.startsWith("CSL") -> "CSL"
            "_STR" in upper || upper.startsWith("STR") -> "STR"
            else -> "EDF"
        }
    }
}

private class DoubleArrayBuilder(initialCapacity: Int) {
    private var data = DoubleArray(max(16, initialCapacity))
    private var size = 0

    fun add(value: Double) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = value
    }

    fun toArray(): DoubleArray = data.copyOf(size)
}

private fun ByteArray.toAscii(): String = String(this, Charset.forName("US-ASCII"))

private fun InputStream.readExactly(length: Int): ByteArray {
    return readExactlyOrNull(length) ?: throw EOFException("Unexpected end of EDF file")
}

private fun InputStream.readExactlyOrNull(length: Int): ByteArray? {
    if (length == 0) return ByteArray(0)
    val result = ByteArray(length)
    var offset = 0
    while (offset < length) {
        val count = read(result, offset, length - offset)
        if (count < 0) return if (offset == 0) null else throw EOFException("Unexpected end of EDF record")
        if (count == 0) continue
        offset += count
    }
    return result
}
