package com.example.cpapcsvexporter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import com.example.cpapcsvexporter.edf.EdfParser
import com.example.cpapcsvexporter.edf.ParsedEdfFile
import com.example.cpapcsvexporter.export.CsvExporter
import com.example.cpapcsvexporter.storage.NightScanner
import com.example.cpapcsvexporter.storage.StorageTree
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : Activity() {
    companion object {
        private const val PICK_SOURCE = 1001
        private const val PREFS = "cpap_csv_exporter"
        private const val PREF_TREE = "storage_tree_uri"
        private const val PREF_SOURCE_ID = "source_document_id"
        private const val PREF_OUTPUT_ID = "output_document_id"
    }

    private lateinit var sourceText: TextView
    private lateinit var outputText: TextView
    private lateinit var dateSpinner: Spinner
    private lateinit var scanButton: Button
    private lateinit var mergedButton: Button
    private lateinit var individualButton: Button
    private lateinit var statusText: TextView

    private var storageTreeUri: Uri? = null
    private var sourceDocumentId: String? = null
    private var outputDocumentId: String? = null
    private var nights: List<NightScanner.Night> = emptyList()
    private val zoneId: ZoneId = ZoneId.systemDefault()
    private val displayDate = DateTimeFormatter.ofPattern("EEEE, MMMM d, yyyy", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        restoreSelections()
        updateButtons()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(32))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "CPAP CSV Exporter"
            textSize = 26f
            setPadding(0, 0, 0, dp(12))
        })

        root.addView(TextView(this).apply {
            text = "For now, read the ResMed SD card on Windows and copy the entire DATALOG folder, or its EDF files, onto your phone. This app uses a phone folder named ResMed Data and does not require OSCAR or Python."
            textSize = 18f
            setPadding(0, 0, 0, dp(14))
        })

        root.addView(Button(this).apply {
            text = "1. Create or choose ResMed Data folder"
            contentDescription = "Step 1. Create or choose the ResMed Data folder on this phone"
            setOnClickListener { chooseSourceLocation() }
        })
        sourceText = TextView(this).apply {
            textSize = 17f
            setPadding(0, dp(6), 0, dp(8))
        }
        root.addView(sourceText)

        outputText = TextView(this).apply {
            textSize = 16f
            setPadding(0, 0, 0, dp(18))
        }
        root.addView(outputText)

        scanButton = Button(this).apply {
            text = "2. Scan available nights"
            setOnClickListener { scanNights() }
        }
        root.addView(scanButton)

        root.addView(TextView(this).apply {
            text = "3. Choose sleep date"
            textSize = 18f
            setPadding(0, dp(16), 0, dp(6))
        })
        dateSpinner = Spinner(this)
        root.addView(dateSpinner)

        mergedButton = Button(this).apply {
            text = "Export one merged CSV"
            contentDescription = "Export one merged CSV with high resolution breathing and slower CPAP measurements aligned by time"
            setPadding(dp(10), dp(12), dp(10), dp(12))
            setOnClickListener { exportMerged() }
        }
        root.addView(mergedButton)

        individualButton = Button(this).apply {
            text = "Export separate CSV files"
            contentDescription = "Convert each EDF file for the selected night to its own CSV file"
            setOnClickListener { exportIndividual() }
        }
        root.addView(individualButton)

        statusText = TextView(this).apply {
            text = "Set up the ResMed Data folder to begin. The app will also create a CSV Exports folder inside it."
            textSize = 18f
            setPadding(0, dp(20), 0, 0)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        }
        root.addView(statusText)

        setContentView(scroll)
    }

    private fun restoreSelections() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        storageTreeUri = prefs.getString(PREF_TREE, null)?.let(Uri::parse)
        sourceDocumentId = prefs.getString(PREF_SOURCE_ID, null)
        outputDocumentId = prefs.getString(PREF_OUTPUT_ID, null)

        val ready = storageTreeUri != null && sourceDocumentId != null && outputDocumentId != null
        sourceText.text = if (ready) "ResMed Data folder: ready" else "ResMed Data folder has not been set up yet."
        outputText.text = if (ready) "CSV output: ResMed Data / CSV Exports" else "CSV Exports will be created inside ResMed Data."
    }

    private fun chooseSourceLocation() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, PICK_SOURCE)
    }

    @Deprecated("Deprecated by Android but intentionally used to avoid an AndroidX dependency in this small app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || requestCode != PICK_SOURCE) return
        val selectedTree = data?.data ?: return
        val takeFlags = data.flags and (
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        )
        runCatching { contentResolver.takePersistableUriPermission(selectedTree, takeFlags) }

        setBusy(true, "Setting up ResMed Data and CSV Exports folders…")
        Thread {
            try {
                val selected = StorageTree(this, selectedTree)
                val sourceNode = if (selected.root.name.equals("ResMed Data", ignoreCase = true)) {
                    selected.root
                } else {
                    selected.ensureDirectory("ResMed Data")
                }
                val sourceTree = StorageTree(this, selectedTree, sourceNode.documentId)
                val outputNode = sourceTree.ensureDirectory("CSV Exports")

                val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
                prefs.edit()
                    .putString(PREF_TREE, selectedTree.toString())
                    .putString(PREF_SOURCE_ID, sourceNode.documentId)
                    .putString(PREF_OUTPUT_ID, outputNode.documentId)
                    .apply()

                runOnUiThread {
                    storageTreeUri = selectedTree
                    sourceDocumentId = sourceNode.documentId
                    outputDocumentId = outputNode.documentId
                    sourceText.text = "ResMed Data folder: ready"
                    outputText.text = "CSV output: ResMed Data / CSV Exports"
                    nights = emptyList()
                    setNightChoices(emptyList())
                    status("Folder setup is ready. Copy your ResMed DATALOG folder or EDF files into ResMed Data, then tap Scan available nights.")
                    setBusy(false)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status("Folder setup failed: ${t.message ?: t.javaClass.simpleName}")
                    setBusy(false)
                }
            }
        }.start()
    }

    private fun scanNights() {
        val tree = storageTreeUri ?: return
        val sourceId = sourceDocumentId ?: return
        setBusy(true, "Scanning the ResMed Data folder for EDF files…")
        Thread {
            try {
                val scanner = NightScanner(StorageTree(this, tree, sourceId), zoneId)
                val result = scanner.scan()
                runOnUiThread {
                    nights = result
                    setNightChoices(result)
                    if (result.isEmpty()) {
                        status("No EDF nights were found. Make sure the selected ResMed Data folder contains the copied DATALOG files or their dated subfolders.")
                    } else {
                        status("Found ${result.size} sleep dates. The newest date is selected.")
                    }
                    setBusy(false)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status("Scan failed: ${t.message ?: t.javaClass.simpleName}")
                    setBusy(false)
                }
            }
        }.start()
    }

    private fun setNightChoices(result: List<NightScanner.Night>) {
        val labels = result.map { "${displayDate.format(it.date)} — ${it.nodes.size} EDF files" }
        dateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        dateSpinner.isEnabled = result.isNotEmpty()
        updateButtons()
    }

    private fun exportMerged() {
        val night = selectedNight() ?: return
        val tree = storageTreeUri ?: return
        val sourceId = sourceDocumentId ?: return
        val outputId = outputDocumentId ?: return

        setBusy(true, "Reading ${night.nodes.size} EDF files for ${night.date}…")
        Thread {
            try {
                val sourceTree = StorageTree(this, tree, sourceId)
                val outputTree = StorageTree(this, tree, outputId)
                val parsed = parseNight(sourceTree, night)
                val fileName = "cpap_${night.date}_merged.csv"
                val (_, stream) = outputTree.createFile(fileName)
                stream.use { CsvExporter(zoneId).exportMerged(parsed, it) }
                runOnUiThread {
                    status("Done. Created $fileName. It includes the high-resolution flow waveform when BRP data is present.")
                    setBusy(false)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status("Export failed: ${t.message ?: t.javaClass.simpleName}")
                    setBusy(false)
                }
            }
        }.start()
    }

    private fun exportIndividual() {
        val night = selectedNight() ?: return
        val tree = storageTreeUri ?: return
        val sourceId = sourceDocumentId ?: return
        val outputId = outputDocumentId ?: return

        setBusy(true, "Converting ${night.nodes.size} EDF files…")
        Thread {
            try {
                val sourceTree = StorageTree(this, tree, sourceId)
                val outputTree = StorageTree(this, tree, outputId)
                val parser = EdfParser(zoneId)
                val exporter = CsvExporter(zoneId)
                var count = 0
                for ((index, node) in night.nodes.withIndex()) {
                    runOnUiThread { status("Converting ${index + 1} of ${night.nodes.size}: ${node.name}") }
                    val parsed = sourceTree.openInput(node).use { parser.parse(node.name, it) }
                    val name = exporter.suggestedIndividualName(node.name)
                    val (_, stream) = outputTree.createFile(name)
                    stream.use { exporter.exportSingleFile(parsed, it) }
                    count++
                }
                runOnUiThread {
                    status("Done. Created $count CSV files for ${displayDate.format(night.date)}.")
                    setBusy(false)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    status("Export failed: ${t.message ?: t.javaClass.simpleName}")
                    setBusy(false)
                }
            }
        }.start()
    }

    private fun parseNight(sourceTree: StorageTree, night: NightScanner.Night): List<ParsedEdfFile> {
        val parser = EdfParser(zoneId)
        val parsed = ArrayList<ParsedEdfFile>(night.nodes.size)
        for ((index, node) in night.nodes.withIndex()) {
            runOnUiThread { status("Reading ${index + 1} of ${night.nodes.size}: ${node.name}") }
            parsed += sourceTree.openInput(node).use { parser.parse(node.name, it) }
        }
        return parsed
    }

    private fun selectedNight(): NightScanner.Night? {
        val position = dateSpinner.selectedItemPosition
        return nights.getOrNull(position)
    }

    private fun setBusy(busy: Boolean, message: String? = null) {
        scanButton.isEnabled = !busy && storageTreeUri != null && sourceDocumentId != null
        mergedButton.isEnabled = !busy && nights.isNotEmpty() && outputDocumentId != null
        individualButton.isEnabled = !busy && nights.isNotEmpty() && outputDocumentId != null
        dateSpinner.isEnabled = !busy && nights.isNotEmpty()
        if (message != null) status(message)
    }

    private fun updateButtons() {
        scanButton.isEnabled = storageTreeUri != null && sourceDocumentId != null
        mergedButton.isEnabled = nights.isNotEmpty() && outputDocumentId != null
        individualButton.isEnabled = nights.isNotEmpty() && outputDocumentId != null
    }

    private fun status(message: String) {
        statusText.text = message
        statusText.announceForAccessibility(message)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
