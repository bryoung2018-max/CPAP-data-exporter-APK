package com.example.cpapcsvexporter.export

import com.example.cpapcsvexporter.edf.EdfEvent
import com.example.cpapcsvexporter.edf.EdfSignalSeries
import com.example.cpapcsvexporter.edf.ParsedEdfFile
import java.io.OutputStream
import java.io.OutputStreamWriter
import java.io.Writer
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.floor

class CsvExporter(
    private val zoneId: ZoneId = ZoneId.systemDefault()
) {
    data class Column(
        val name: String,
        val unit: String,
        val series: List<EdfSignalSeries>
    )

    private val timestampFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)

    fun exportMerged(files: List<ParsedEdfFile>, output: OutputStream) {
        val allSignals = files.flatMap { it.signals }
        require(allSignals.isNotEmpty()) { "No numeric EDF signals were found for this date." }
        val allEvents = files.flatMap { it.events }.sortedBy { it.onsetEpochMillis }

        val columns = buildColumns(allSignals)
        val masters = chooseMasterSeries(columns)
        require(masters.isNotEmpty()) { "No usable time-series data was found." }

        OutputStreamWriter(output, Charsets.UTF_8).buffered(128 * 1024).use { writer ->
            writeTimeSeries(writer, columns, masters, allEvents)
        }
    }

    fun exportSingleFile(file: ParsedEdfFile, output: OutputStream) {
        OutputStreamWriter(output, Charsets.UTF_8).buffered(64 * 1024).use { writer ->
            if (file.signals.isEmpty()) {
                writeEventsOnly(writer, file.events)
            } else {
                val columns = buildColumns(file.signals)
                val master = file.signals.minByOrNull { it.sampleIntervalMillis }
                    ?: error("No usable signals")
                writeTimeSeries(writer, columns, listOf(master), file.events.sortedBy { it.onsetEpochMillis })
            }
        }
    }

    fun suggestedIndividualName(edfName: String): String {
        return edfName.replace(Regex("(?i)\\.edf$"), "") + ".csv"
    }

    private fun buildColumns(signals: List<EdfSignalSeries>): List<Column> {
        val grouped = linkedMapOf<String, MutableList<EdfSignalSeries>>()
        for (signal in signals.sortedWith(compareBy<EdfSignalSeries> { it.startEpochMillis }.thenBy { it.label })) {
            val key = canonicalName(signal)
            grouped.getOrPut(key) { mutableListOf() }.add(signal)
        }

        return grouped.entries.map { (name, series) ->
            val units = series.map { it.unit.trim() }.filter { it.isNotEmpty() }.distinct()
            Column(name, units.joinToString("/"), series.sortedBy { it.startEpochMillis })
        }.sortedWith(compareBy<Column> { columnOrder(it.name) }.thenBy { it.name })
    }

    private fun chooseMasterSeries(columns: List<Column>): List<EdfSignalSeries> {
        val flow = columns.firstOrNull { it.name == "flow_rate" }
        if (flow != null) return flow.series.sortedBy { it.startEpochMillis }

        val bestColumn = columns.minByOrNull { column ->
            column.series.minOfOrNull { it.sampleIntervalMillis } ?: Double.MAX_VALUE
        } ?: return emptyList()
        return bestColumn.series.sortedBy { it.startEpochMillis }
    }

    private fun writeTimeSeries(
        writer: Writer,
        columns: List<Column>,
        masters: List<EdfSignalSeries>,
        events: List<EdfEvent>
    ) {
        writer.append("timestamp_local,epoch_ms")
        for (column in columns) writer.append(',').append(csv(column.name))
        writer.append(",event,event_duration_seconds\n")

        val cursors = columns.map { SeriesCursor(it.series) }
        var eventIndex = 0

        for (master in masters.sortedBy { it.startEpochMillis }) {
            val step = master.sampleIntervalMillis
            if (step <= 0.0 || master.values.isEmpty()) continue
            val segmentStart = master.startEpochMillis.toDouble()
            val segmentEndExclusive = segmentStart + step * master.values.size

            while (eventIndex < events.size && events[eventIndex].onsetEpochMillis < segmentStart) {
                eventIndex++
            }

            for (i in master.values.indices) {
                val timeDouble = segmentStart + i * step
                val epochMs = timeDouble.toLong()
                val nextTime = timeDouble + step
                val local = Instant.ofEpochMilli(epochMs).atZone(zoneId).toLocalDateTime()

                writer.append(timestampFormatter.format(local))
                    .append(',')
                    .append(epochMs.toString())

                for (cursor in cursors) {
                    writer.append(',')
                    val value = cursor.valueAt(timeDouble)
                    if (value != null && value.isFinite()) writer.append(number(value))
                }

                val rowEvents = mutableListOf<EdfEvent>()
                while (eventIndex < events.size) {
                    val event = events[eventIndex]
                    val onset = event.onsetEpochMillis.toDouble()
                    if (onset >= nextTime) break
                    if (onset >= timeDouble && onset < segmentEndExclusive) rowEvents += event
                    eventIndex++
                }

                writer.append(',')
                if (rowEvents.isNotEmpty()) {
                    writer.append(csv(rowEvents.joinToString(" | ") { it.text }))
                }
                writer.append(',')
                if (rowEvents.isNotEmpty()) {
                    writer.append(csv(rowEvents.joinToString(" | ") { it.durationSeconds?.let(::number) ?: "" }))
                }
                writer.append('\n')
            }
        }
    }

    private fun writeEventsOnly(writer: Writer, events: List<EdfEvent>) {
        writer.append("timestamp_local,epoch_ms,event,event_duration_seconds\n")
        for (event in events.sortedBy { it.onsetEpochMillis }) {
            val local = Instant.ofEpochMilli(event.onsetEpochMillis).atZone(zoneId).toLocalDateTime()
            writer.append(timestampFormatter.format(local)).append(',')
                .append(event.onsetEpochMillis.toString()).append(',')
                .append(csv(event.text)).append(',')
            event.durationSeconds?.let { writer.append(number(it)) }
            writer.append('\n')
        }
    }

    private fun canonicalName(signal: EdfSignalSeries): String {
        val compact = signal.label.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "")
        return when {
            compact.startsWith("flowlim") || (compact.contains("flow") && compact.contains("lim")) -> "flow_limitation"
            compact.startsWith("flow") -> "flow_rate"
            compact.startsWith("press") && (compact.contains("40ms") || signal.sourceType == "BRP") -> "mask_pressure_wave"
            compact.startsWith("maskpress") -> "mask_pressure"
            compact.startsWith("eprpress") -> "epr_pressure"
            compact.startsWith("press") -> "pressure"
            compact.startsWith("leak") -> "leak"
            compact.startsWith("resprate") || compact.startsWith("respiratoryrate") -> "respiratory_rate"
            compact.startsWith("tidvol") || compact.startsWith("tidalvolume") -> "tidal_volume"
            compact.startsWith("minvent") || compact.startsWith("minutevent") -> "minute_ventilation"
            compact.startsWith("snore") -> "snore"
            compact.startsWith("pulse") -> "pulse"
            compact.startsWith("spo2") || compact.startsWith("sao2") -> "spo2"
            else -> "${signal.sourceType.lowercase(Locale.US)}_${snake(signal.label)}"
        }
    }

    private fun snake(text: String): String {
        return text.trim().lowercase(Locale.US)
            .replace(Regex("[^a-z0-9]+"), "_")
            .trim('_')
            .ifEmpty { "signal" }
    }

    private fun columnOrder(name: String): Int = when (name) {
        "flow_rate" -> 0
        "mask_pressure_wave" -> 1
        "mask_pressure" -> 2
        "pressure" -> 3
        "epr_pressure" -> 4
        "leak" -> 5
        "respiratory_rate" -> 6
        "tidal_volume" -> 7
        "minute_ventilation" -> 8
        "flow_limitation" -> 9
        "snore" -> 10
        "pulse" -> 11
        "spo2" -> 12
        else -> 100
    }

    private fun number(value: Double): String {
        if (value == 0.0) return "0"
        val rounded = kotlin.math.round(value * 1_000_000.0) / 1_000_000.0
        return java.lang.Double.toString(rounded)
    }

    private fun csv(value: String): String {
        if (!value.contains(',') && !value.contains('"') && !value.contains('\n') && !value.contains('\r')) {
            return value
        }
        return "\"" + value.replace("\"", "\"\"") + "\""
    }
}

private class SeriesCursor(series: List<EdfSignalSeries>) {
    private val series = series.sortedBy { it.startEpochMillis }
    private var index = 0

    fun valueAt(epochMillis: Double): Double? {
        while (index < series.size) {
            val current = series[index]
            val endExclusive = current.startEpochMillis + current.sampleIntervalMillis * current.values.size
            if (epochMillis >= endExclusive) {
                index++
                continue
            }
            if (epochMillis < current.startEpochMillis) return null
            if (current.sampleIntervalMillis <= 0.0 || current.values.isEmpty()) return null
            val sample = floor((epochMillis - current.startEpochMillis) / current.sampleIntervalMillis + 1e-9).toInt()
            return current.values.getOrNull(sample)
        }
        return null
    }
}
