package com.example.cpapcsvexporter.storage

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.InputStream
import java.io.OutputStream

/**
 * Wrapper around one user-granted Storage Access Framework tree.
 *
 * [treeUri] is always the URI Android actually granted. [rootDocumentId] may point at
 * a descendant directory inside that tree. Keeping the original granted tree URI is
 * important because Android's persisted permission belongs to that URI, while this
 * class can still treat a descendant such as "ResMed Data" or "CSV Exports" as its root.
 */
class StorageTree(
    private val context: Context,
    val treeUri: Uri,
    private val rootDocumentId: String? = null
) {
    data class Node(
        val name: String,
        val mimeType: String,
        val uri: Uri,
        val documentId: String
    ) {
        val isDirectory: Boolean
            get() = mimeType == DocumentsContract.Document.MIME_TYPE_DIR
    }

    private val resolver: ContentResolver = context.contentResolver

    val root: Node by lazy {
        val id = rootDocumentId ?: DocumentsContract.getTreeDocumentId(treeUri)
        val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
        val name = queryName(uri) ?: "Selected folder"
        Node(name, DocumentsContract.Document.MIME_TYPE_DIR, uri, id)
    }

    fun listChildren(parent: Node): List<Node> {
        require(parent.isDirectory)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parent.documentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val result = mutableListOf<Node>()
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val typeColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val id = cursor.getString(idColumn)
                val name = cursor.getString(nameColumn) ?: ""
                val type = cursor.getString(typeColumn) ?: "application/octet-stream"
                val uri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
                result += Node(name, type, uri, id)
            }
        }
        return result
    }

    /** Finds an existing child directory or creates it under [parent]. */
    fun ensureDirectory(name: String, parent: Node = root): Node {
        listChildren(parent).firstOrNull {
            it.isDirectory && it.name.equals(name, ignoreCase = true)
        }?.let { return it }

        val created = DocumentsContract.createDocument(
            resolver,
            parent.uri,
            DocumentsContract.Document.MIME_TYPE_DIR,
            name
        ) ?: error("Could not create folder $name")

        val documentId = DocumentsContract.getDocumentId(created)
        val displayName = queryName(created) ?: name
        return Node(displayName, DocumentsContract.Document.MIME_TYPE_DIR, created, documentId)
    }

    fun openInput(node: Node): InputStream {
        return resolver.openInputStream(node.uri)
            ?: error("Could not open ${node.name}")
    }

    fun createFile(name: String, mimeType: String = "text/csv"): Pair<Uri, OutputStream> {
        val rootNode = root
        // Re-exporting the same night should replace the old CSV instead of creating
        // confusing duplicate names such as "(1)" whenever the provider allows deletion.
        listChildren(rootNode).firstOrNull {
            !it.isDirectory && it.name.equals(name, ignoreCase = true)
        }?.let { old -> runCatching { DocumentsContract.deleteDocument(resolver, old.uri) } }

        val created = DocumentsContract.createDocument(resolver, rootNode.uri, mimeType, name)
            ?: error("Could not create $name in the selected output folder")
        val output = resolver.openOutputStream(created, "w")
            ?: error("Could not open $name for writing")
        return created to output
    }

    private fun queryName(uri: Uri): String? {
        val projection = arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
        return resolver.query(uri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }
}
