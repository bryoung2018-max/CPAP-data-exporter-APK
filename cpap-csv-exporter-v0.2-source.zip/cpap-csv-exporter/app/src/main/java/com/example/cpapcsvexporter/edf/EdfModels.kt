package com.example.cpapcsvexporter.edf

import java.time.LocalDateTime

data class EdfSignalHeader(
    val label: String,
    val physicalDimension: String,
    val physicalMinimum: Double,
    val physicalMaximum: Double,
    val digitalMinimum: Int,
    val digitalMaximum: Int,
    val samplesPerRecord: Int
) {
    val isAnnotation: Boolean
        get() = label.trim().equals("EDF Annotations", ignoreCase = true)
}

data class EdfHeader(
    val version: String,
    val recordingId: String,
    val startDateTime: LocalDateTime,
    val headerBytes: Int,
    val reserved: String,
    val numberOfDataRecords: Long,
    val recordDurationSeconds: Double,
    val signals: List<EdfSignalHeader>
)

data class EdfSignalSeries(
    val label: String,
    val unit: String,
    val sourceType: String,
    val sourceName: String,
    val startEpochMillis: Long,
    val sampleIntervalMillis: Double,
    val values: DoubleArray
) {
    val endEpochMillis: Double
        get() = if (values.isEmpty()) startEpochMillis.toDouble()
        else startEpochMillis + sampleIntervalMillis * (values.size - 1)
}

data class EdfEvent(
    val onsetEpochMillis: Long,
    val durationSeconds: Double?,
    val text: String,
    val sourceName: String
)

data class ParsedEdfFile(
    val sourceName: String,
    val sourceType: String,
    val header: EdfHeader,
    val signals: List<EdfSignalSeries>,
    val events: List<EdfEvent>
)
