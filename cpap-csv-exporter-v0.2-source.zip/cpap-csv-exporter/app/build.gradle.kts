plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.cpapcsvexporter"
    compileSdk = 37

    defaultConfig {
        applicationId = "com.example.cpapcsvexporter"
        minSdk = 26
        targetSdk = 36
        versionCode = 2
        versionName = "0.2.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
